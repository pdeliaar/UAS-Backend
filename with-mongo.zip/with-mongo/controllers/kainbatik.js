const Kainbatik = require('../models/kbEmbedded')


module.exports = {
    insert : async (req,res)=>{
        //Ambil data request dari front end
        const data = new Kainbatik({
            nomor : req.body.nomor,
            namabatik : req.body.namabatik,
            tanggalbeli : req.body.tanggalbeli,
            tanggalbeli : req.body.tanggalbeli,
        })
        try {
            const dataToSave = await data.save()
            res.status(200).json(dataToSave)
        } catch (error) {
            res.status(400).json({message:error.message})
        }
    },

    insertProduk: async (req,res)=>{
        const size = req.params.size

        try{
            await Kainbatik.updateOne(
                {"nomor":nomor},
                {
                    $push:{
                        "produk":{
                            "kode": req.body.kode,
                            "jenisbatik": req.body.jenisbatik,
                            "kualitas":req.body.kualitas,
                            'ukuranbatik':req.body.ukuranbatik,
                            "harga": req.body.harga,
                        }
                    }
                })
            res.send('Produk telah di simpan')
            } catch (error){
                res.status(409).json({message: error.message})
            }
    },
    
    getBatik : async (req,res)=>{
        try {
            const result = await Kainbatik.find()
            res.status(200).json(result)
        } catch (error) {
            res.status(404).json({message : error.message})
        }
    },
    getBatikByNomor : async (req,res)=>{
         const nomor = req.params.nomor
         try {
             const result = await kainbatik.find().where('nomor').equals(nomor)
             res.json(result)
         } catch (error) {
             res.status(500).json({message: error.message})
         }
    },

    getKainBatikByNomor : async (req,res) => {
        const nomor = req.params.nomor;
        try{
            const result = await batik.findOne({"nomor": nomor}, {"_id":0,"produk": 1})
            /* let res2 =[];
            for (let i = 0; i < result.lenght i++){
                res2.push(result[i])
            }*/
            res.json(result)
        } catch (error){
            res.status(500).json({ message : error.message})
        }
    },
    update : async (req,res)=>{
        const filter = {size : req.params.nomor}
        const updatedData = {
            namabatik : req.body.namabatik,
            tanggalbeli : req.body.tanggalbeli,
            namapembeli: req.body.namapembeli
        }
        try {
            let result = await kainbatik.updateOne(filter,updatedData)
            res.send('Data telah terupdate')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    },

    delete : async (req,res)=>{
        const filter = {nomor : req.params.nomor}
        try {
            await kainbatik.deleteOne(filter);
            res.send('Data telah terhapus')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    }
}