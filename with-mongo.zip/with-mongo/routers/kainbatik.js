const express = require("express");
const routerKainbatik = express.Router()
const controllerKainbatik = require('../controllers/sepatu')

routerKainbatik.route('/kainbatik')
    .get(controllerKainbatik.getKainbatik)
    .post(controllerKainbatik.insert)

routerKainbatik.route('/kainbatik/:nomor')
    .put(controllerKainbatik.update)
    .delete(controllerKainbatik.delete)
    .get(controllerKainbatik.getKainbatikByNomor)

routerKainbatik.route('/kainbatik/produk/:nomor')
    .get(controllerKainbatik.getProdukByNomor)
    .put(controllerKainbatik.insertProduk)

module.exports = routerKainbatik