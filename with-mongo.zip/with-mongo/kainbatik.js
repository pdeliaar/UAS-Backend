const express = require("express");
const routerKainbatik = express.Router()

let kainbatik = [{Nomor:'111', namaBatik:'kopi', tanggalBeli: '18-02-2021', namaPembeli:'delia',create:new Date()},
                 {Nomor:'112', namaBatik:'gajah oling', tanggalBeli: '28-07-2021', namaPembeli:'dhila',create:new Date()},
                 {Nomor:'113', namaBatik:'paras gempal', tanggalBeli: '21-11-2021', namaPembeli:'nurin',create:new Date()},
                ]

const cari = (arrData,nomor) =>{
    ketemu = -1
    indeks = 0
    while(ketemu == -1 && indeks < arrData.length){
        if(arrData[indeks].nomor == nomor){
            ketemu = indeks
            return indeks
        }
        indeks++
    }
    return -1
}

routerKainbatik.route('/batik')
    .get( (req,res)=>{
        res.json(kainbatik)
    })

    .post((req,res)=>{
        //Ambil data request dari front end
        const newItem = {
            nomor : req.body.nomor,
            namabatik : req.bodya.namabatik,
            tanggalbeli : req.body.tanggalbeli,
            namapembeli : req.body.namapembeli
        }
        kainbatik.push(newItem)
        res.status(201).json(newItem)
    })

routerKainbatik.route('/kainbatik/:nomor')
    .put((req,res)=>{
       nomor = req.params.nomor
        indeks = cari(kainbatik,nomor)
        if(indeks != -1){
            kainbatik[indeks].nomor = nomor
            kainbatik[indeks].namabatik = req.body.namabatik
            kainbatik[indeks].tanggalbeli = req.body.tanggalbeli
            kainbatik[indeks].namapembeli = req.body.namapembeli

            res.json(kainbatik[indeks])
        }
        else{
            res.send('Data kain batik tidak ditemukan')
        }
        
    })

    .delete((req,res)=>{
        nomor = req.params.nomor
        indeks = cari(kainbatik,nomor)
        if(indeks != -1){
            kainbatik.splice(indeks,1)
            res.send('Kain batik dengan size ' + nomor + ' telah dihapus')
        }
        else
        {
            res.send('Data kain batik tidak ditemukan')
        }
        
    })

    .get((req,res)=>{
        nomor = req.params.nomor
        indeks = cari(kainbatik,nomor)
        if(indeks != -1){
            const dataKainbatik = {nomor:kainbatik[indeks].nomor,
                                   warna:kainbatik[indeks].namabatik,
                                   namabatik:kainbatik[indeks].tanggalbeli,
                                   harga:kainbatik[indeks].namapembeli
                                  }
            res.json(dataKainbatik)
        }
        else{
            res.send('Batik dengan nomor : ' + nomor + ' tidak ditemukan')
        }
        
    })

routerBatik.get('/kainbatik/:namabatik/:terlaris', (req,res)=>{
    const warna = req.params.namabatik
    const terlaris = req.params.terlaris
    res.send('namabatik : ' + namabatik+ ' terlaris : ' + terlaris)
})

module.exports = routerKainbatik