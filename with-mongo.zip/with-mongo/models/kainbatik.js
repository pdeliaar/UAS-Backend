const mongoose = require('mongoose')

const kainbatikSchema = new mongoose.Schema({
    nomor : {
        require : true,
        type : String
    },
    namabatik : String,
    tanggalbeli : String,
    namapembeli : String,
})

module.exports = mongoose.model('kainbatik', kbSchema,'kainbatik')