const mongoose = require('mongoose')

const sptEmbeddedSchema = new mongoose.Schema({
    nomor:{
        required: true,
        type: String
    },
    namabatik:{
        required: true,
        type: String
    },
    tanggalbeli:{
        required: true,
        type: String
    },
    namapembeli:{
        required: true,
        type: String
    },
    produk: [{
        kode : String,
        jenisbatikk : String,
        kualitas : String,
        ukuranbatik : String,
        harga : String
    }]
})

module.exports = mongoose.model('kainbatik', sptEmbeddedSchema,'kainbatik')